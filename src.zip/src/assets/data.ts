
export const tableData={
    "tableData": [
        {
            "position": 1,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 2,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 3,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 4,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 5,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 6,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 7,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 8,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 9,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
        {
            "position": 10,
            "userid": "bk200100",
            "role": 'QA Initiator',
            "lifeCycle": "RQPI-QA-NCIAI-LC-87",
            "moduleName":"Action item management",
            "module":'NCI'
        },
      
    ]
}