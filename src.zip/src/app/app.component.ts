import { Component,OnInit } from '@angular/core';
import {ToolbarService} from './service/toolbar.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'royal';
  applicationshow:any;
  

  constructor(public toolbarService:ToolbarService){
   // sessionStorage.removeItem("isLogin");
  }

  ngOnInit(): void {
   // this.applicationshow=sessionStorage.getItem('isLogin');
   //this.applicationshow=this.toolbarService.isLogin;
    console.log(this.applicationshow)
  }
}
