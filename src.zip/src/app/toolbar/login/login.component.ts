import { Component ,OnInit} from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
import {ToolbarService} from '../../service/toolbar.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit{

  hide = true;
  LoginForm: FormGroup;
  constructor(public fb: FormBuilder,private route:Router,private toolbarService:ToolbarService){
    this.LoginForm = this.fb.group({
      userid:[''],
      password:[''],
    }); 
  }
  ngOnInit(): void {
  }
  
  onLogin(){
    console.log('testing')
    this.toolbarService.isLogin='loginSuccess';
    sessionStorage.setItem('isLogin','loginSuccess')
    console.log(sessionStorage.getItem('isLogin'))
    this.route.navigate(['./data-table'])
  }
  onForgetPassword(){
    console.log('working')
    this.toolbarService.isLogin='forgetPassword';
    sessionStorage.setItem('isLogin','forgetPassword')
    console.log(sessionStorage.getItem('isLogin'))
     this.route.navigate(['./forget-password']);
  }
}
