import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {ToolbarService} from '../../service/toolbar.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit{

  color = "accent";
  constructor(private route: Router, private router: ActivatedRoute,public toolbarService:ToolbarService){

  }
  ngOnInit(): void {
  }
  
  navigatehome() {
    console.log("clicked")
    this.route.navigate(['/']);
  }
  onLogout(){
    this.toolbarService.isLogin="loginFaild";
  }
  onChangePassword(){
    console.log('working')
    //this.route.navigate(['./data-table'])
    this.route.navigate(['./change-password'])
  }

}
