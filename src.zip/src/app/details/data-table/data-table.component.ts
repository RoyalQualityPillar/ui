import { Component,AfterViewInit,ViewChild,OnInit,ViewEncapsulation } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { MatSort, Sort } from '@angular/material/sort';
import {tableData} from '../../../assets/data';
import {LiveAnnouncer} from '@angular/cdk/a11y';
import { ActivatedRoute, Router } from '@angular/router';
import {ToolbarService} from '../../service/toolbar.service';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
  // encapsulation : ViewEncapsulation.None,
})
export class DataTableComponent implements OnInit ,AfterViewInit {

  //@ViewChild(MatSort) sort = new MatSort();
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator,{static: false})paginator!: MatPaginator;

  displayedColumns: string[] = ['position','action', 'userid', 'role', 'lifeCycle','moduleName','module'];
 // dataSource = ELEMENT_DATA;
 dataSource:any;
  

  constructor(private _liveAnnouncer: LiveAnnouncer,private route: Router, private router: ActivatedRoute,public toolbarService:ToolbarService){}
  ngOnInit(): void {
  this.dataSource=tableData.tableData;
  this.dataSource.paginator = this.paginator;
  this.dataSource.sort = this.sort;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    
  }
  copyData() {
    var dataArray = "";
    this.dataSource.forEach(row => {
      // console.log(row)
      // console.log("before: ", dataArray);
      dataArray += this.ObjectToArray(row)
      // console.log("after: ", dataArray);
    })
  
    return dataArray;
  }
  
    ObjectToArray(obj: any): string {
      let result = Object.keys(obj).map((key: keyof typeof obj) => {
        let value = obj[key];
        // console.log(value)
        return value;
      });
      console.log(result.toString())
      return result.toString() + "\n";
    }


    onPrint() {
      // do other stuff...
      window.print();
    }
    announceSortChange(sortState: Sort) {
      console.log('working')
      if (sortState.direction) {
        this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
      } else {
        this._liveAnnouncer.announce('Sorting cleared');
      }
    }

    moduleHomePage(){
      this.route.navigate(['./module-home-page'])
    }
    //print
}







